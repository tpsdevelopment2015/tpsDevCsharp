﻿using System;
using System.Collections.Generic;
using System.IO;


namespace CodeSample
{
    class GuessingGame : GuessingGameBase
    {
        public GuessingGame(int minimum, int maximum, int number) : base(minimum, maximum, number) { }

        /// <summary>
        /// Using only the information you have access to in gameState, return 
        /// the number for the next guess. After each guess, you will know 
        /// whether the guess was High, Low, or Correct. 
        /// 
        /// Modify this method and add any methods you may need.
        /// </summary>
        /// <param name="gameState"></param>
        /// <returns>The next guess.</returns>
        public static int NextGuess(GuessingGame gameState)
        {
            throw new NotImplementedException();
        }
    }


    class JumpToConclusions : JumpToConclusionsBase
    {
        public JumpToConclusions(int[] gameBoard) : base(gameBoard) { }

        /// <summary>
        /// Find the smallest cost to move to the end of the array. The cost is 
        /// calculated by adding the value of each element on your path to the 
        /// end of the array. Starting at position 0, reach the end of the array 
        /// by executing a sequence of moves. Each move is either a "step" to 
        /// the next element (current position + 1) or a "jump" to the element 
        /// after that (current position + 2). Arrays will have a length of 1 
        /// or greater.
        /// 
        /// For example, if GameBoard is {1, 5, 2, 7, 22, 14, 8, 9}, 
        /// the smallest cost is 33 by moving to positions 0, 2, 3, 5, and 7.
        ///     GameBoard[0] + GameBoard[2] + GameBoard[3] + GameBoard[5] + GameBoard[7] == 33
        /// 
        /// Modify this method and add any methods you may need.
        /// </summary>
        /// <returns>The cost.</returns>
        public override int CalculateCost()
        {
            throw new NotImplementedException();
        }
    }


    class WordCounter : WordCounterBase
    {
        public WordCounter(StreamReader inputStream, StreamWriter outputStream) : base(inputStream, outputStream) { }

        /// <summary>
        /// Return a list of WordEntry objects, one for each unique word. Each 
        /// WordEntry object in the list should contain word and the correct 
        /// count of occurences of that word in the appropriate properties.
        /// 
        /// Modify this method and add any methods you may need.
        /// </summary>
        /// <returns>An IEnumerable of WordEntry objects with the counts calculated.</returns>
        public override IEnumerable<WordEntry> GetWordCount()
        {
            throw new NotImplementedException();
        }
    }
}
